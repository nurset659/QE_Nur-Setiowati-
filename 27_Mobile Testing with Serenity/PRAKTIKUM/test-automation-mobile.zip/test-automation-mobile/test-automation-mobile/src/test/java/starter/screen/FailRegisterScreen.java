package starter.screen;

import com.github.javafaker.Faker;
import io.appium.java_client.MobileBy;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;
import test.automation.pageobject.BasePageObject;

public class FailRegisterScreen extends BasePageObject {
    public String name = createRandomName();

    public String password = "password123";

    private By failregisterLink(){
        return MobileBy.id("textViewLinkRegister");
    }

    private By failnameField(){
        return MobileBy.id("textInputEditTextName");
    }

    private By failemailField(){
        return MobileBy.id("textInputEditTextEmail");
    }

    private By failpasswordField(){
        return MobileBy.id("textInputEditTextPassword");
    }

    private By failconfirmPasswordField(){
        return MobileBy.id("textInputEditTextConfirmPassword");
    }

    private By failregisterButton(){
        return MobileBy.id("appCompatButtonRegister");
    }

    private By FailMessage(){
        return MobileBy.xpath("\t\n" +
                "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.ScrollView/android.support.v7.widget.LinearLayoutCompat/TextInputLayout[2]/android.widget.LinearLayout/android.widget.TextView");
    }

    @Step
    public void failclickRegisterLink(){
        onClick(failregisterLink());
    }

    @Step
    public void failinputNameField(){
        onType(failnameField(), createRandomName());
    }

    public void failinputEmailField(){
        onType(failemailField(), createRandomName() );
    }

    @Step
    public void failinputPassword(){
        onType(failpasswordField(), password);
    }

    @Step
    public void failconfirmPassword(){
        onType(failconfirmPasswordField(), password);
    }

    @Step
    public void failclickRegisterButton(){
        onClick(failregisterButton());
    }

    @Step
    public String getFailMessage(){
        return waitUntilVisible(FailMessage()).getText();
    }

    public String createRandomName(){
        Faker faker = new Faker();
        return faker.name().firstName();
    }
}
