package starter.stepdefinitions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import org.junit.Assert;
import starter.screen.LoginScreen;
import starter.screen.FailRegisterScreen;

public class FailRegisterSteps {
    @Steps
    LoginScreen loginScreen;

    @Steps
    FailRegisterScreen failRegisterScreen;


    @When("New user can click register link")
    public void failuserClickRegisterLink(){
        failRegisterScreen.failclickRegisterLink();
    }

    @And("New user can input name on name field")
    public void failinputNameField(){
        failRegisterScreen.failinputNameField();
    }

    @And("New user can input email on email field")
    public void failinputEmailField(){
        failRegisterScreen.failinputEmailField();
    }

    @And("New user can input password on password field")
    public void failinputPasswordField(){
        failRegisterScreen.failinputPassword();
    }

    @And("New user can confirm password")
    public void failconfirmPassword(){
        failRegisterScreen.failconfirmPassword();
    }

    @And("New user can click register button")
    public void failclickRegisterButton(){
        failRegisterScreen.failclickRegisterButton();
    }

    @Then("New user see warning message {string}")
    public void seeFailRegister(String message){
        Assert.assertEquals(message, failRegisterScreen.getFailMessage());
    }
}
