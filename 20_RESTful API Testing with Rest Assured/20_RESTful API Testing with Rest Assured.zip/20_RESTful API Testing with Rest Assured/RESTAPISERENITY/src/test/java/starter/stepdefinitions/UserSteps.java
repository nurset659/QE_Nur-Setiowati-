package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.user.*;

public class UserSteps {
    @Steps
    Get get;
    @Steps
    NEGATIVEPOST negativepost;
    @Steps
    POST post;

    @Steps
    GetId getid;

    @Steps
    NEGATIVEGETID negatifGetId;

    @Steps
    PUT put;

    @Steps
    PUTNEGATIVE putnegative;

    @Steps
    DELETE delete;

    @Steps
    DELNEG delneg;


    //DETAIL USER
    @Given("set Get api endpoint")
    public void ApiEndpointsGet() {
        get.setApiEndpoint();

    }
    @When("admin set GET Http request")
    public void sendGetHttpRequest() {
        get.sendGetHttpRequest();
    }

    @Then("admin receive HTTP response code 200")
    public void receiveValidHttpResponse() {
        get.validateHttpResponseCode200();
    }

    @And("admin receive valid data")
    public void receiveValidDataForDetailUser() {
        get.validateDataDetailUser();
    }


    //
    @Given("I set Get to get some data")
    public void iSetGetToGetSomeData() {
        get.setToSomeData();
    }

    @When("I need Set GET Http request")
    public void NeedsendGetHttpRequest() {
        get.NeedSetGetHttpRequest();
    }

    @Then("I assume valid HTTP response code {int}")
    public void AssumeValidHttpResponseCode404(int arg0) {
        get.AssumeValidHttpResponseCode404();
    }


    @Given("I want to post new user data")
    public void iWantToPostNewUserData() {
        post.iWantToPostNewUserData();
    }

    @When("I need Set POST Http request")
    public void NeedSetPostHttpRequest() {
        post.NeedSetPostHttpRequest();
    }

    @Then("I got valid HTTP response code {int}")
    public void iGotValidHTTPResponseCode201(int arg0) {
        post.iGotValidHTTPResponseCode201();
    }


    @Given("I want to post new user data for new")
    public void iWantToPostNewUserDataForNew() {
        negativepost.iWantToPostNewUserDataForNew();
    }

    @When("I need Set POST Http request for post")
    public void NeedSetPOSTHttpRequestForPost() {
        negativepost.NeedSetPOSTHttpRequestForPost();
    }

    @Then("I see you again HTTP response code 404")
    public void SeeYouAgainHTTPResponseCode404() {
        negativepost.SeeYouAgainHTTPResponseCode404();
    }
    

    @Given("I set Getid to get some data")
    public void SetGetidToGetSomeData() {
        getid.SetGetidToGetSomeData();
    }

    @When("I need Set GetId Http request")
    public void iNeedSetGetIdHttpRequest() {
        getid.iNeedSetGetIdHttpRequest();
    }


    @Then("I see Http response code {int}")
    public void iSeeHttpResponseCode200(int arg0) {
        getid.iSeeHttpResponseCode200();
    }

    @Given("I set Getid to get some data but failed")
    public void SetGetidToGetSomeDataButFailed() {
        negatifGetId.SetGetidToGetSomeDataButFailed();
    }

    @When("I need Set GetId Http request for failed")
    public void NeedSetGetIdHttpRequestForFailed() {
        negatifGetId.NeedSetGetIdHttpRequestForFailed();
    }

    @Then("running Getid Http Code 404")
    public void runningGetidHttpCode404(int arg0) {
        negatifGetId.runningGetidHttpCode404();
    }

    @Given("I set PUT to change data post by id")
    public void iSetPUTToChangeDataPostById() {
        put.iSetPUTToChangeDataPostById();
    }

    @When("I need Set PUT Http request")
    public void iNeedSetPUTHttpRequest() {
        put.iNeedSetPUTHttpRequest();
    }

    @Then("Give me Http Code {int}")
    public void giveMeHttpCode(int arg0) {
        put.giveMeHttpCode();
    }

    @Given("I can't change the data with method PUT")
    public void iCanTChangeTheDataWithMethodPUT() {
    putnegative.iCanTChangeTheDataWithMethodPUT();
    }


    @When("I can't set PUT Http request")
    public void iCanTSetPUTHttpRequest() {
        putnegative.iCanTSetPUTHttpRequest();
    }


    @Then("give me different Http code {int}")
    public void giveDifferentMeHttpCode(int arg0) {
        putnegative.giveDifferentMeHttpCode();
    }

    @Given("I set can DELETE data")
    public void iSetCanDELETEData() {
        delete.iSetCanDELETEData();
    }

    @When("I can set DELETE Http Request")
    public void iCanSetDELETEHttpRequest() {
        delete.iCanSetDELETEHttpRequest();
    }

    @Then("give Http code {int}")
    public void giveHttpCode(int arg0) {
        delete.giveHttpCode();
    }

    @Given("I set can't DELETE data")
    public void iSetCanTDELETEData() {
        delneg.iSetCanTDELETEData();
    }

    @When("I can't set DELETE Http Request")
    public void iCanTSetDELETEHttpRequest() {
        delneg.iCanTSetDELETEHttpRequest();
    }


    @Then("Oops Sorry Http code {int}")
    public void oopsSorryHttpCode(int arg0) {
        delneg.oopsSorryHttpCode();
    }
}

