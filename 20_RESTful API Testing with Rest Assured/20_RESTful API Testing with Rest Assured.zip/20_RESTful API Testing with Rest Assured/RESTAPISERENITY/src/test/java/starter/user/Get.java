package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import static org.hamcrest.Matchers.equalTo;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class Get {
    public static String url = "https://jsonplaceholder.typicode.com/posts";


    @Step("I set Get api endpoint")
    public String setApiEndpoint() {
        return url;
    }

    @Step("I Set GET Http request")
    public void sendGetHttpRequest() {
        SerenityRest.given().get(setApiEndpoint());
    }

    @Step("I receive valid HTTP response code 200")
    public void validateHttpResponseCode200() {
        restAssuredThat(response -> response.statusCode(200));
    }

    @Step("I receive valid data for detail user")
    public void validateDataDetailUser() {
        restAssuredThat(response -> response.body("[0].id", equalTo(1)));
        restAssuredThat(response -> response.body("[0].title", equalTo("sunt aut facere repellat provident occaecati excepturi optio reprehenderit")));
    }

    @Step("I set to Get some data")
    public String setToSomeData() {
        return url;
    }

    @Step("I need Set GET Http request")
    public void NeedSetGetHttpRequest() {
        SerenityRest.given().get(setToSomeData());

    }

    @Step("I assume valid HTTP response code 404")
    public void AssumeValidHttpResponseCode404() {
        restAssuredThat(response -> response.statusCode(400));
    }



}




