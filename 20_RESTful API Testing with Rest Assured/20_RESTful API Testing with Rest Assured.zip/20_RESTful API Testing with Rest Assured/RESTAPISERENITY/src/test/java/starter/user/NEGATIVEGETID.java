package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class NEGATIVEGETID {

    public static String url = "https://jsonplaceholder.typicode.com/posts/1 ";

    @Step("I set Getid to get some data but failed")
    public String SetGetidToGetSomeDataButFailed() {
        return url;
    }
    @Step("I need Set GetId Http request for failed")
    public void NeedSetGetIdHttpRequestForFailed() {
        SerenityRest.given().get(SetGetidToGetSomeDataButFailed());
    }

    @Step("running Getid Http Code 404")
    public void runningGetidHttpCode404() {
        restAssuredThat(response -> response.statusCode(404));
    }
}
