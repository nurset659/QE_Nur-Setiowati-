package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class DELETE {

    public static String url = "https://jsonplaceholder.typicode.com/posts";

    @Step("I set can DELETE data")
    public String iSetCanDELETEData() {
        return url;
    }

    @Step("I can set DELETE Http Request")
    public void iCanSetDELETEHttpRequest() {
        SerenityRest.given().delete(iSetCanDELETEData());
    }

    @Step("give Http code {int}")
    public void giveHttpCode() {
        restAssuredThat(response -> response.statusCode(404));
    }
}
