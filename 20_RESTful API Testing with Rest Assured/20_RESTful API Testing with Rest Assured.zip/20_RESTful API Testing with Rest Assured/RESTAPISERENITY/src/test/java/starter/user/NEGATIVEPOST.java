package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.JSONObject;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class NEGATIVEPOST {

    public static String url = "https://jsonplaceholder.typicode.com/posts";

    @Step("I want to post new user data for new")
    public String iWantToPostNewUserDataForNew()  {
        return url + "/ABG";
    }
    @Step("I need Set POST Http request for post")
    public void NeedSetPOSTHttpRequestForPost() {
        JSONObject requestBody = new JSONObject();
        requestBody.put("title", "sunt aut facere repellat provident occaecati excepturi optio reprehenderit");
        requestBody.put("body", "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto");
        SerenityRest.given().header("Content-Type", "application/json").body(requestBody.toString()).post(iWantToPostNewUserDataForNew());

    }

    @Step("I see you again HTTP response code {int}")
    public void SeeYouAgainHTTPResponseCode404() {
        restAssuredThat(response -> response.statusCode(404));
    }


}
