package starter.stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class forgotPassword {
    @Given("user at homepage")
    public void userAtHomepage() {
        System.out.println("user at homepage");
    }

    @When("the user clicks on the Forgot Password link")
    public void ForgotPasswordLink() {
        System.out.println("the user clicks on the Forgot Password link");
    }

    @Then("the user should be redirected to the password reset page")
    public void PasswordResetPage() {
        System.out.println("the user should be redirected to the password reset page");
    }
}
