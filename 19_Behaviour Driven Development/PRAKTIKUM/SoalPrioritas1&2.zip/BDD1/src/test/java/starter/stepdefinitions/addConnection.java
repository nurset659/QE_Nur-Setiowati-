package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class addConnection {
    @Given("user at dashboard")
    public void userAtDashboard() {
        System.out.println("user at dashboard");
    }

    @When("the user clicks on the My Network button")
    public void clickNetworkButton() {
        System.out.println("user clicks on the My Network button");
    }

    @And("clicks on the Connect button next to a users profile")
    public void clickConnectBtn() {
        System.out.println("clicks on the Connect button next to a users profile");
    }

    @And("sends a connection request")
    public void sendsAConnectionRequest() {
        System.out.println("sends a connection request");
    }

    @Then("the user should receive a notification when their connection request is accepted")
    public void Receivenotif() {
        System.out.println("the user should receive a notification when their connection request is accepted");
    }
}
