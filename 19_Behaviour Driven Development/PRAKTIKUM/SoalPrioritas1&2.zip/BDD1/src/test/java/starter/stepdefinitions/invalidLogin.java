package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class invalidLogin {
    @Given("the user the  linkedIn homepage")
    public void theUserTheLinkedInHomepage() {
        System.out.println("the user the  linkedIn homepage");
    }


    @Then("an error message should appear on the login page")
    public void anErrorMessageShouldAppearOnTheLoginPage() {
    }

    @When("the user enters invalid login credentials")
    public void EntersInvalidLoginCredentials() {
        System.out.println("the user enters invalid login credentials");
    }

    @And("and clicks the login button")
    public void ClicksLoginButton() {
        System.out.println("and clicks the login button");
    }
}
