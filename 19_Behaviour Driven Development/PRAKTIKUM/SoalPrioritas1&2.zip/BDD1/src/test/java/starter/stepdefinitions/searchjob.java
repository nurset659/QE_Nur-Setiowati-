package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class searchjob {
    @Given("user on dashboard")
    public void userOnDashboard() {
//        System.out.println("tes");
    }

    @When("the user types in a job keyword in the search bar")
    public void theUserTypesInAJobKeywordInTheSearchBar() {
//        System.out.println("tes");
    }

    @And("clicks on the Search button")
    public void clicksOnTheSearchButton() {
//        System.out.println("tes");
    }

    @Then("the user should be redirected to the job search results page")
    public void theUserShouldBeRedirectedToTheJobSearchResultsPage() {
//        System.out.println("tes");
    }
}
