package starter.pilihProduk;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Step;

public class topUpPulsa {

    @Step ("i am on the home screen Sepulsa application")
    public void iAmOnTheHomeScreenSepulsaApplication() {

    }

    @Step("i am selects the Pulsa option")
    public void iAmSelectsThePulsaOption() {
    }

    @Step("enters my phone number and the desired credit amount")
    public void entersMyPhoneNumberAndTheDesiredCreditAmount() {
    }

    @Step("confirms the transaction by entering my PIN dana")
    public void confirmsTheTransactionByEnteringMyPINDana() {
    }

    @Step("the system should process the transaction and display a success message")
    public void theSystemShouldProcessTheTransactionAndDisplayASuccessMessage() {
    }

    @Step("i am at sepulsa homescreen")
    public void iAmAtSepulsaHomescreen() {

    }

    @Step("i am enters an invalid phone number")
    public void iAmEntersAnInvalidPhoneNumber() {
    }

    @Step("enters the desired credit amount")
    public void entersTheDesiredCreditAmount() {
    }

    @Step("confirms the transaction by entering my dana PIN")
    public void confirmsTheTransactionByEnteringMyDanaPIN() {
    }

    @Step("the system should display an error message indicating that the phone number is invalid")
    public void theSystemShouldDisplayAnErrorMessageIndicatingThatThePhoneNumberIsInvalid() {
    }

    @Step("i am on  Pulsa screen of the Sepulsa application")
    public void iAmOnPulsaScreenOfTheSepulsaApplication() {
    }

    @Step("i am enters a credit amount that is not supported by their mobile provider")
    public void iAmEntersACreditAmountThatIsNotSupportedByTheirMobileProvider() {
    }

    @Step("enters my phone number")
    public void entersMyPhoneNumber() {
    }

    @Step("confirms the transaction by entering their PIN")
    public void confirmsTheTransactionByEnteringTheirPIN() {
    }

    @Step("the system should display an error message indicating that the credit amount is not supported")
    public void theSystemShouldDisplayAnErrorMessageIndicatingThatTheCreditAmountIsNotSupported() {
    }
}
