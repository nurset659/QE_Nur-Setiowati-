package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.pilihProduk.topUpPulsa;

public class pulsaTopUp {


    @Steps
    topUpPulsa pls;
    @Given("i am on the home screen Sepulsa application")
    public void iAmOnTheHomeScreenSepulsaApplication() {
        pls.iAmOnTheHomeScreenSepulsaApplication();

    }

    @When("i am selects the Pulsa option")
    public void iAmSelectsThePulsaOption() {
        pls.iAmSelectsThePulsaOption();
    }

    @And("enters my phone number and the desired credit amount")
    public void entersMyPhoneNumberAndTheDesiredCreditAmount() {
        pls.entersMyPhoneNumberAndTheDesiredCreditAmount();
    }

    @And("confirms the transaction by entering my PIN dana")
    public void confirmsTheTransactionByEnteringMyPINDana() {
        pls.confirmsTheTransactionByEnteringMyPINDana();
    }


    @Then("the system should process the transaction and display a success message")
    public void theSystemShouldProcessTheTransactionAndDisplayASuccessMessage() {
        pls.theSystemShouldProcessTheTransactionAndDisplayASuccessMessage();
    }

    @Given("i am at sepulsa homescreen")
    public void iAmAtSepulsaHomescreen() {
        pls.iAmAtSepulsaHomescreen();
    }

    @When("i am enters an invalid phone number")
    public void iAmEntersAnInvalidPhoneNumber() {
        pls.iAmEntersAnInvalidPhoneNumber();
    }

    @And("enters the desired credit amount")
    public void entersTheDesiredCreditAmount() {
        pls.entersTheDesiredCreditAmount();
    }

    @And("confirms the transaction by entering my dana PIN")
    public void confirmsTheTransactionByEnteringMyDanaPIN() {
        pls.confirmsTheTransactionByEnteringMyDanaPIN();
    }

    @Then("the system should display an error message indicating that the phone number is invalid")
    public void theSystemShouldDisplayAnErrorMessageIndicatingThatThePhoneNumberIsInvalid() {
        pls.theSystemShouldDisplayAnErrorMessageIndicatingThatThePhoneNumberIsInvalid();
    }

    @Given("i am on  Pulsa screen of the Sepulsa application")
    public void iAmOnPulsaScreenOfTheSepulsaApplication() {
        pls.iAmOnPulsaScreenOfTheSepulsaApplication();
    }

    @When("i am enters a credit amount that is not supported by their mobile provider")
    public void iAmEntersACreditAmountThatIsNotSupportedByTheirMobileProvider() {
        pls.iAmEntersACreditAmountThatIsNotSupportedByTheirMobileProvider();
    }

    @And("enters my phone number")
    public void entersMyPhoneNumber() {
        pls.entersMyPhoneNumber();
    }

    @And("confirms the transaction by entering their PIN")
    public void confirmsTheTransactionByEnteringTheirPIN() {
        pls.confirmsTheTransactionByEnteringTheirPIN();
    }

    @Then("the system should display an error message indicating that the credit amount is not supported")
    public void theSystemShouldDisplayAnErrorMessageIndicatingThatTheCreditAmountIsNotSupported() {
        pls.theSystemShouldDisplayAnErrorMessageIndicatingThatTheCreditAmountIsNotSupported();
    }
}
