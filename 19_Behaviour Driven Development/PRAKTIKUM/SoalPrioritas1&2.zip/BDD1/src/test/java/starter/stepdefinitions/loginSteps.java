package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class loginSteps {
    @When("the user clicks the Sign In button")
    public void theUserClicksTheButton() {
        System.out.println("s1");
    }

    @Given("user is on the LinkedIn homepage")
    public void userIsOnTheLinkedInHomepage() {
        System.out.println("s1");
    }

    @And("the user enters the correct email and password")
    public void theUserEntersTheCorrectEmailAndPassword() {
        System.out.println("s1");
    }

    @Then("the user will be directed to the LinkedIn profile page")
    public void theUserWillBeDirectedToTheLinkedInProfilePage() {
        System.out.println("s1");
    }
}
