package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class postStatus {
    @Given("user at LinkedIn homepage")
    public void userAtLinkedInHomepage() {
    }

    @When("the user clicks on the Start a post button")
    public void theUserClicksOnTheStartAPostButton() {
    }

    @And("enters a status update in the text box")
    public void entersAStatusUpdateInTheTextBox() {
    }

    @And("clicks on the Post button")
    public void clicksOnThePostButton() {
    }

    @Then("the users status update should be visible to their LinkedIn connections")
    public void theUsersStatusUpdateShouldBeVisibleToTheirLinkedInConnections() {
    }
}
