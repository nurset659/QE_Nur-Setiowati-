package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.login.LoginSepulsa;

public class loginSepulsa {
    @Steps
    LoginSepulsa login;
    @Given("I am on the Sepulsa login page")
    public void iAmOnTheSepulsaLoginPage() {
        login.iAmOnTheSepulsaLoginPage();
    }

    @When("I enter valid login credentials")
    public void iEnterValidLoginCredentials() {
        login.iEnterValidLoginCredentials();
    }

    @And("click the login button")
    public void clickTheLoginButton() {
        login.clickTheLoginButton();
    }

    @Then("I should be redirected to my account dashboard")
    public void iShouldBeRedirectedToMyAccountDashboard() {
        login.iShouldBeRedirectedToMyAccountDashboard();
    }

    @When("I enter invalid login credentials")
    public void iEnterInvalidLoginCredentials() {
        login.iEnterInvalidLoginCredentials();
    }

    @Then("I should see an error message indicating the login was unsuccessful")
    public void seeAnErrorMessage() {
        login.SeeAnErrorMessage();
    }

    @Then("I should see an error message indicating the email format is invalid")
    public void errorEmailFormatIsInvalid() {
        login.errorEmailFormatIsInvalid();
    }

    @When("I enter an invalid email format in the email field")
    public void enterInvalidEmail() {
        login.enterInvalidEmail();
    }
}
