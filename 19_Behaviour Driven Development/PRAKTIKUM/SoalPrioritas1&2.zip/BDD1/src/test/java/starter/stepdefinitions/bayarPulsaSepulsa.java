package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.pembayaran.bayarPulsa;

public class bayarPulsaSepulsa {

    @Steps
    bayarPulsa bp;
    @Given("I have sufficient balance in my account")
    public void iHaveSufficientBalanceInMyAccount() {
        bp.iHaveSufficientBalanceInMyAccount();
    }

    @When("I select the mobile phone credit purchase service")
    public void iSelectTheMobilePhoneCreditPurchaseService() {
        bp.iSelectTheMobilePhoneCreditPurchaseService();
    }

    @And("i am enter my mobile phone number")
    public void iAmEnterMyMobilePhoneNumber() {
        bp.iAmEnterMyMobilePhoneNumber();
    }

    @And("I choose the desired amount of credit to be purchased")
    public void iChooseTheDesiredAmountOfCreditToBePurchased() {
        bp.iChooseTheDesiredAmountOfCreditToBePurchased();
    }

    @And("I select the payment method as Sepulsa balance")
    public void iSelectThePaymentMethodAsSepulsaBalance() {
        bp.iSelectThePaymentMethodAsSepulsaBalance();
    }

    @Then("the payment amount will be deducted from my Sepulsa balance and the mobile phone credit will be added to my mobile phone number")
    public void thePaymentAmountWillBeDeductedFromMySepulsaBalanceAndTheMobilePhoneCreditWillBeAddedToMyMobilePhoneNumber() {
        bp.thePaymentAmountWillBeDeductedFromMySepulsaBalanceAndTheMobilePhoneCreditWillBeAddedToMyMobilePhoneNumber();
    }

    @Given("I am a registered user of Sepulsa.com and I have sufficient balance in my account")
    public void iAmARegisteredUserOfSepulsaComAndIHaveSufficientBalanceInMyAccount() {
        bp.iAmARegisteredUserOfSepulsaComAndIHaveSufficientBalanceInMyAccount();
    }

    @When("I select the mobile phone credit purchase service and enter my mobile phone number")
    public void iSelectTheMobilePhoneCreditPurchaseServiceAndEnterMyMobilePhoneNumber() {
        bp.iSelectTheMobilePhoneCreditPurchaseServiceAndEnterMyMobilePhoneNumber();
    }

    @And("I choose  desired amount of credit to be purchased")
    public void iChooseDesiredAmountOfCreditToBePurchased() {
        bp.iChooseDesiredAmountOfCreditToBePurchased();
    }

    @And("I select the payment method as Virtual Account")
    public void iSelectThePaymentMethodAsVirtualAccount() {
        bp.iSelectThePaymentMethodAsVirtualAccount();
    }

    @Then("the payment amount will be transferred from my Sepulsa balance to the virtual account and the mobile phone credit will be added to my mobile phone number.")
    public void thePaymentAmountWillBeTransferredFromMySepulsaBalanceToTheVirtualAccountAndTheMobilePhoneCreditWillBeAddedToMyMobilePhoneNumber() {
        bp.thePaymentAmountWillBeTransferredFromMySepulsaBalanceToTheVirtualAccountAndTheMobilePhoneCreditWillBeAddedToMyMobilePhoneNumber();
    }

    @And("I select the payment method as Bank Transfer")
    public void iSelectThePaymentMethodAsBankTransfer() {
        bp.iSelectThePaymentMethodAsBankTransfer();
    }

    @Then("the payment amount will be transferred from my bank account to the virtual account of Sepulsa.com and the mobile phone credit will be added to my mobile phone number")
    public void thePaymentAmountWillBeTransferredFromMyBankAccountToTheVirtualAccountOfSepulsaComAndTheMobilePhoneCreditWillBeAddedToMyMobilePhoneNumber() {
        bp.thePaymentAmountWillBeTransferredFromMyBankAccountToTheVirtualAccountOfSepulsaComAndTheMobilePhoneCreditWillBeAddedToMyMobilePhoneNumber();
    }
}
