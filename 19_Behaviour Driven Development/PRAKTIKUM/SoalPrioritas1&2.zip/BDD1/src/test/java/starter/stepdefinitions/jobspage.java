package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class jobspage {

    @Given("user at LinkedIn dashboard")
    public void userAtLinkedInDashboard() {
        System.out.println("user at LinkedIn dashboard");
    }

    @When("the user clicks on the Jobs link")
    public void ClicksOnTheJobsLink() {
        System.out.println("the user clicks on the Jobs link");
    }

    @Then("the user should be redirected to the LinkedIn Jobs page")
    public void RedirectedToJobsPage() {
        System.out.println("the user should be redirected to the LinkedIn Jobs page");
    }


}
