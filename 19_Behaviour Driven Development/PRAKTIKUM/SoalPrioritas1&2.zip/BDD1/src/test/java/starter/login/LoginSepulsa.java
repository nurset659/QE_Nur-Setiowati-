package starter.login;


import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Step;

public class LoginSepulsa {

    @Step("I am on the Sepulsa login page")
    public void iAmOnTheSepulsaLoginPage() {
        System.out.println("I am on the Sepulsa login page");
    }

    @Step("I enter valid login credentials")
    public void iEnterValidLoginCredentials() {
        System.out.println("I enter valid login credentials");
    }

    @Step("click the login button")
    public void clickTheLoginButton() {
        System.out.println("click the login button");
    }

    @Step("I should be redirected to my account dashboard")
    public void iShouldBeRedirectedToMyAccountDashboard() {
        System.out.println("I should be redirected to my account dashboard");
    }

    @Step("I enter invalid login credentials")
    public void iEnterInvalidLoginCredentials() {
        System.out.println("I enter invalid login credentials");
    }

    @Step("I should see an error message indicating the login was unsuccessful")
    public void SeeAnErrorMessage() {
        System.out.println("I should see an error message indicating the login was unsuccessful");
    }

    @Step("I should see an error message indicating the email format is invalid")
    public void errorEmailFormatIsInvalid() {
        System.out.println("I should see an error message indicating the email format is invalid");
    }

    @When("I enter an invalid email format in the email field")
    public void enterInvalidEmail() {
        System.out.println("I enter an invalid email format in the email field");
    }
}
