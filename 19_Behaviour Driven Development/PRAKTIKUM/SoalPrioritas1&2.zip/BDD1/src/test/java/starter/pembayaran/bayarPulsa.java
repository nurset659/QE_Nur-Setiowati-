package starter.pembayaran;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Step;

public class bayarPulsa {
    @Step("I have sufficient balance in my account")
    public void iHaveSufficientBalanceInMyAccount() {
    }

    @Step("I select the mobile phone credit purchase service")
    public void iSelectTheMobilePhoneCreditPurchaseService() {
    }

    @Step("i am enter my mobile phone number")
    public void iAmEnterMyMobilePhoneNumber() {
    }

    @Step("I choose the desired amount of credit to be purchased")
    public void iChooseTheDesiredAmountOfCreditToBePurchased() {
    }

    @Step("I select the payment method as Sepulsa balance")
    public void iSelectThePaymentMethodAsSepulsaBalance() {
    }

    @Step("the payment amount will be deducted from my Sepulsa balance and the mobile phone credit will be added to my mobile phone number")
    public void thePaymentAmountWillBeDeductedFromMySepulsaBalanceAndTheMobilePhoneCreditWillBeAddedToMyMobilePhoneNumber() {
    }

    @Step("I am a registered user of Sepulsa.com and I have sufficient balance in my account")
    public void iAmARegisteredUserOfSepulsaComAndIHaveSufficientBalanceInMyAccount() {
    }

    @Step("I select the mobile phone credit purchase service and enter my mobile phone number")
    public void iSelectTheMobilePhoneCreditPurchaseServiceAndEnterMyMobilePhoneNumber() {
    }

    @Step("I choose  desired amount of credit to be purchased")
    public void iChooseDesiredAmountOfCreditToBePurchased() {
    }

    @Step("I select the payment method as Virtual Account")
    public void iSelectThePaymentMethodAsVirtualAccount() {
    }

    @Step("the payment amount will be transferred from my Sepulsa balance to the virtual account and the mobile phone credit will be added to my mobile phone number.")
    public void thePaymentAmountWillBeTransferredFromMySepulsaBalanceToTheVirtualAccountAndTheMobilePhoneCreditWillBeAddedToMyMobilePhoneNumber() {
    }

    @Step("I select the payment method as Bank Transfer")
    public void iSelectThePaymentMethodAsBankTransfer() {
    }

    @Step("the payment amount will be transferred from my bank account to the virtual account of Sepulsa.com and the mobile phone credit will be added to my mobile phone number")
    public void thePaymentAmountWillBeTransferredFromMyBankAccountToTheVirtualAccountOfSepulsaComAndTheMobilePhoneCreditWillBeAddedToMyMobilePhoneNumber() {
    }
}
