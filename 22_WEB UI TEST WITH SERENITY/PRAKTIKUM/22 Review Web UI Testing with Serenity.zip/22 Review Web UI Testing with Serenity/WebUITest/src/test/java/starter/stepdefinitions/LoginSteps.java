package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.pages.LoginPage;

public class LoginSteps {

    @Steps
    LoginPage login;




    @Given("user on login page")
    public void userOnLoginPage() throws InterruptedException{
        login.onLoginPage();
    }

    @When("user input valid username")
    public void userInputValidUsername() throws InterruptedException{
        login.inputUserName("standard_user");

    }

    @And("user input valid password")
    public void userInputValidPassword() throws InterruptedException{
        login.inputPassword("secret_sauce");
    }

    @And("user click button button")
    public void userClickButtonButton() throws InterruptedException{
        login.clickLoginButton();
    }

    @Then("user on products page")
    public void userOnProductsPage() throws  InterruptedException{
        System.out.println("berhasil login");
    }


    @Given("user on Home Page")
    public void userOnHomePage() throws InterruptedException {
        login.OnHomePage();
    }

    @When("in the username field is filled with a password")
    public void inTheUsernameFieldIsFilledWithAPassword() throws InterruptedException{
        login.TheUsernameFieldIsFilledWithAPassword("secret_sauce");
    }

    @And("in the password field is filled with the username")
    public void inThePasswordFieldIsFilledWithTheUsername() throws InterruptedException {
        login.ThePasswordFieldIsFilledWithTheUsername("standard_user");
    }

    @And("user click button")
    public void userClickButton() throws InterruptedException {
        login.userClickButton();
    }


    @Then("user see the product")
    public void userSeeTheProduct() throws InterruptedException{
        login.userSeeTheProduct();
    }
}
