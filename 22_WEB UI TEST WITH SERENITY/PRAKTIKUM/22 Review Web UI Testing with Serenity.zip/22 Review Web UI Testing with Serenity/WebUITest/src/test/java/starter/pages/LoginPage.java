package starter.pages;

import net.serenitybdd.core.pages.PageObject;

import net.thucydides.core.annotations.Step;

import org.openqa.selenium.By;

public class LoginPage extends PageObject{


    // ini namanya locator
    private By usernameField() {
        return By.id("user-name");
    }

    private By passwordField() {
        return By.id("password");
    }

    private By loginButon() {
        return By.id("login-button");
    }

    private By products() {
        return By.xpath("//input[@id='login-button']");
    }

    @Step
    public void onLoginPage() {
        open();
        $(loginButon()).shouldBeVisible();

    }



    // inifungsional
    @Step
    public void inputUserName(String username) throws InterruptedException {
        open();
        $(usernameField()).type(username);
        Thread.sleep(1000);
    }

    @Step
    public void inputPassword(String password) throws InterruptedException {
        $(passwordField()).type(password);
        Thread.sleep(1000);
    }

    @Step
    public void clickLoginButton() throws InterruptedException {
        $(loginButon()).click();
        Thread.sleep(1000);
    }


    @Step
    public void OnHomePage() {
        open();
        $(loginButon()).shouldBeVisible();
    }

    @Step
    public void TheUsernameFieldIsFilledWithAPassword(String password) throws InterruptedException {
        open();
        $(usernameField()).type(password);
        Thread.sleep(1000);

    }

    @Step
    public void ThePasswordFieldIsFilledWithTheUsername(String username) throws InterruptedException {
        $(passwordField()).type(username);
        Thread.sleep(1000);
    }

    @Step
    public void userClickButton() throws InterruptedException {
        $(loginButon()).click();
        Thread.sleep(1000);
    }

    @Step
    public void userSeeTheProduct() throws InterruptedException{
        Thread.sleep(1000);
        $(products()).shouldBeVisible();
    }

}
